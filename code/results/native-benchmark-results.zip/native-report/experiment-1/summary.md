# VPTunnel namespace benchmark

- Kernel: `6.18.34-061834-generic` (x86_64)
- 5 runs x 15 s per TCP measurement; UDP offered load 100 Mbit/s
- Network namespaces on one machine: a controlled comparison, not a hardware or Wi-Fi measurement (the two-Pi benchmark reports those).

| config | TCP fwd Mbit/s | TCP rev Mbit/s | UDP Mbit/s | UDP loss % | ping avg ms |
|---|---|---|---|---|---|
| tunnel | 2295.1 +/- 44.6 | 2231.4 +/- 16.8 | 100.0 | 0 | 0.153 |
| baseline | 62540.0 +/- 1288.0 | 62253.8 +/- 964.3 | 100.0 | 0 | 0.076 |

`tunnel` crosses the VPN; `baseline` is the same two host namespaces forwarded directly with no tunnel. The gap is the tunnel's cost: 72 bytes/packet of overhead, ChaCha20-Poly1305, and the kernel data path (which runs in softirq, so its CPU is not attributed to the controller process).
