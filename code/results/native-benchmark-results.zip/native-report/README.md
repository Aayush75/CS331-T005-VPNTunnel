# Native hardware benchmark evidence

Repository base commit: 39851b42fceba6b76ee504a89ab020e97c1a272e.

These experiments execute on the host Linux kernel using network namespaces, without a VM.

## Contents

- `environment.json`: native host CPU, kernel, virtualization detection, tool versions, governor and power information.
- `build-*.log`: build output, including the initial missing GCC 15 failure and successful GCC 14 build.
- `benchmark-fix.patch`: gateway module-detection correction and receiver-side UDP reporting fixes.
- `run_capture.py`: evidence wrapper; invokes the existing benchmark functions with default parameters and retains raw outputs.
- `experiment-1/`: five TCP transfers per direction per configuration, 15 seconds measured per transfer with a 2-second omitted warm-up; UDP at 100 Mbit/s and 50-packet RTT measurement for tunnel and baseline.
- `experiment-2/`: UDP payload sweep, 8 seconds at 200 Mbit/s offered load per payload size.
- `raw/*.json`: exact measurement argv, exit status, stdout (original iperf3 JSON or ping text) and stderr.

## Reproduction

Build the kernel module with `make -C code/kernel W=1 CC=gcc-14` on this host. The installed kernel was built with GCC 15; the available GCC 14 emits warnings for kernel-header attributes, retained in the build log.
Build the controller using Rust 1.93.0 and `cargo build --release --locked --manifest-path code/control/Cargo.toml`.

From the repository root, invoke the wrapper as root with PATH including /usr/sbin, VPTCTL pointing to code/control/target/release/vptctl, and VPT1_DISPOSABLE_VM=yes:

```
python3 code/results/native-report/run_capture.py 1 code/results/native-report/experiment-1
python3 code/results/native-report/run_capture.py 2 code/results/native-report/experiment-2
```

The legacy VPT1_DISPOSABLE_VM variable enables the scripts; it does not launch a VM.
Use distinct output directories for new runs to preserve existing evidence.

## Scope

One native host, sequential tunnel then baseline measurements. These are controlled software-path numbers, not Pi or physical network measurements. CPU governor is powersave and AC power was connected. No CPU affinity, frequency lock or offload tuning was applied. TCP spread is within-session population standard deviation, not a confidence interval across sessions.

The UDP sweep's sizes are UDP payload bytes. IPv4+UDP add 28 bytes to form the inner packet. With a 1428-byte inner IP MTU, 1400 bytes is the largest unfragmented UDP payload; the 1428-byte payload point exceeds that boundary.

No private keys or credentials are included in the evidence bundle.

Use REPORT.md and all-transfers.csv as the authoritative interpreted results. Original script summaries are retained, including the uninterpretable 0% loss field for the zero-receiver 1428-byte point. The base source archive plus benchmark-fix.patch records the source used; experiment 1 used the gateway fix and its UDP values were corrected afterward from raw receiver fields. Experiment 2 used all fixes.
