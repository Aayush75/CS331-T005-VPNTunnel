#!/usr/bin/env python3
"""Run repository benchmark unchanged while preserving raw measurement outputs."""
import sys, os, json, subprocess, importlib, shutil
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools'))
sys.path.insert(0,str(root/'tests/netns'))
out=Path(sys.argv[2]).resolve()
raw=out/'raw'; raw.mkdir(parents=True,exist_ok=True)
original=subprocess.run
counter=0
def captured(*args,**kwargs):
    global counter
    result=original(*args,**kwargs)
    argv=list(args[0]) if args else list(kwargs.get('args',[]))
    if 'iperf3' in argv or 'ping' in argv:
        counter+=1
        name=f'{counter:03d}-'+('iperf3' if 'iperf3' in argv else 'ping')
        (raw/(name+'.json')).write_text(json.dumps(dict(argv=argv,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr),indent=2))
    if result.returncode and 'vpt-gateway.sh' in ' '.join(map(str,argv)):
        print('Gateway command failed:',result.stdout,result.stderr,flush=True)
    return result
subprocess.run=captured
module=importlib.import_module('bench_netns' if sys.argv[1]=='1' else 'bench_packetsize')
sys.argv=[str(root/'tools'/Path(module.__file__).name),'--output',str(out)]
try:
    rc=module.main()
finally:
    for p in Path('/tmp').glob('bench_*/run-*/controller.log'):
        shutil.copy2(p,out/('controller-'+p.parent.name+'.log'))
    for p in Path('/tmp').glob('pktbench_*/run-*/controller.log'):
        shutil.copy2(p,out/('controller-'+p.parent.name+'.log'))
sys.exit(rc or 0)
