# VPTunnel packet-size sweep

- Kernel: `6.18.34-061834-generic` (x86_64); UDP 200 Mbit/s offered, 8 s per size
- vpn0 inner MTU 1428; tunnel overhead 72 bytes/packet

| datagram bytes | delivered Mbit/s | loss % | packets/s |
|---|---|---|---|
| 64 | 84.4 | 0.02 | 164872 |
| 128 | 159.8 | 0.0 | 156093 |
| 256 | 200.0 | 0.0 | 97639 |
| 512 | 200.0 | 0 | 48821 |
| 768 | 199.9 | 0.01 | 32543 |
| 1024 | 200.0 | 0.0 | 24409 |
| 1200 | 200.0 | 0 | 20830 |
| 1300 | 200.0 | 0 | 19228 |
| 1400 | 200.0 | 0 | 17854 |
| 1428 | 0.0 | 0 | 0 |

Small datagrams pay the fixed 72-byte overhead on every packet, so delivered goodput is lower and the packet rate is the limit. Near the 1428-byte inner MTU the overhead is amortised. Inner datagrams that would exceed the underlay MTU once encapsulated are dropped by design (the tunnel does not fragment).
