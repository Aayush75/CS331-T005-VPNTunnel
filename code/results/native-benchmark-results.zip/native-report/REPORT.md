# Native hardware benchmark results

CPU: Intel Core Ultra 7 165H. Kernel: 6.18.34-061834-generic. Native x86-64; no VM. AC power; powersave governor.

One session; five TCP runs per direction/configuration, 15 seconds measured per run with 2 seconds omitted warm-up. UDP offered load: 100 Mbit/s. TCP spread below is population standard deviation.

| Configuration | TCP forward (Mbit/s) | TCP reverse (Mbit/s) | Received UDP (Mbit/s) | UDP loss (%) | Average RTT (ms) |
|---|---:|---:|---:|---:|---:|
| tunnel | 2295.1 ± 44.6 | 2231.4 ± 16.8 | 99.991 | 0.0000 | 0.153 |
| baseline | 62540.0 ± 1288.0 | 62253.8 ± 964.3 | 99.991 | 0.0000 | 0.076 |

Forward TCP reduction: 96.33%. Reverse TCP reduction: 96.42%.
Added average RTT: 0.077 ms.

## Packet-size sweep

UDP offered load: 200 Mbit/s, 8 seconds per UDP payload size; one observation per size. Receiver-side measurements.

| UDP payload bytes | Sent Mbit/s | Received Mbit/s | Loss % | Received packets/s | Status |
|---:|---:|---:|---:|---:|---|
| 64 | 84.431 | 84.415 | 0.0168 | 164872 | OK |
| 128 | 159.844 | 159.839 | 0.0003 | 156093 | OK |
| 256 | 199.969 | 199.966 | 0.0003 | 97639 | OK |
| 512 | 199.973 | 199.970 | 0.0000 | 48821 | OK |
| 768 | 199.971 | 199.943 | 0.0108 | 32543 | OK |
| 1024 | 199.969 | 199.962 | 0.0005 | 24409 | OK |
| 1200 | 199.970 | 199.965 | 0.0000 | 20830 | OK |
| 1300 | 199.974 | 199.972 | 0.0000 | 19228 | OK |
| 1400 | 199.971 | 199.965 | 0.0000 | 17854 | OK |
| 1428 | 0.001 | 0.000 | N/A | 0 | No packets received |

## Interpretation and limits

These namespace measurements compare native software paths on one machine; they do not measure Pi performance or a physical Ethernet link. Baseline follows tunnel in a single session, without CPU pinning or frequency locking. Five TCP observations give within-session spread; UDP/RTT and sweep points do not have across-session uncertainty estimates.

When sent throughput is below offered load, low received goodput alone does not establish tunnel saturation; sender pacing/generation limits may contribute. The sweep is a fixed-offered-load measurement, not a maximum-capacity search.

At 1428-byte payload, iperf3 recorded one sender datagram and zero receiver packets. Its raw 0% loss field is not a valid delivery/loss conclusion; report loss as unavailable. This run establishes no delivery at that size, not sustained-load loss percentage.

UDP payload plus 28 bytes of IPv4/UDP headers forms the inner IP packet. The 1400-byte payload fits the 1428-byte inner MTU; the 1428-byte payload exceeds the unfragmented boundary. Consult raw outcomes rather than assuming MTU behavior.

The original experiment-1 summary uses iperf3 end.sum for UDP; the table here is corrected from the preserved end.sum_received fields. TCP values are unchanged. Experiment 2 ran with receiver-side extraction and received-packet-rate fixes.

The module was compiled with GCC 14 against a GCC-15-built kernel; header warnings and successful build/load evidence are retained. Gateway module detection also required a one-line fix. See benchmark-fix.patch.

See all-transfers.csv for every transfer, raw JSON for independent verification, README.md for reproduction, and environment.json for host metadata.
