import csv, json, statistics
from pathlib import Path
root=Path(__file__).resolve().parent
measurements=[]
for exp in (1,2):
    for path in sorted((root/f'experiment-{exp}'/'raw').glob('*iperf3.json')):
        record=json.loads(path.read_text())
        data=json.loads(record['stdout'])
        path.with_suffix('.iperf.json').write_text(json.dumps(data,indent=2)+'\n')
        argv=record['argv']; end=data.get('end',{}); recv=end.get('sum_received',{})
        udp='-u' in argv
        seconds=recv.get('seconds',0)
        measurements.append(dict(experiment=exp,file=str(path.relative_to(root)),protocol='UDP' if udp else 'TCP',direction='reverse' if '-R' in argv else 'forward',payload_bytes=int(argv[argv.index('-l')+1]) if '-l' in argv else '',returncode=record['returncode'],error=data.get('error',''),sent_mbps=end.get('sum_sent',{}).get('bits_per_second',0)/1e6,received_mbps=recv.get('bits_per_second',0)/1e6 if recv else '',loss_pct=recv.get('lost_percent','') if recv.get('packets',0) else '',received_pps=(recv.get('packets',0)-recv.get('lost_packets',0))/seconds if seconds and udp else ''))
with (root/'all-transfers.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=list(measurements[0]));writer.writeheader();writer.writerows(measurements)
r=json.loads((root/'experiment-1'/'benchmark.json').read_text())
udps=[x for x in measurements if x['experiment']==1 and x['protocol']=='UDP']
assert len(r['configs'])==2 and len(udps)==2
lines=['# Native hardware benchmark results','', 'CPU: Intel Core Ultra 7 165H. Kernel: 6.18.34-061834-generic. Native x86-64; no VM. AC power; powersave governor.','', 'One session; five TCP runs per direction/configuration, 15 seconds measured per run with 2 seconds omitted warm-up. UDP offered load: 100 Mbit/s. TCP spread below is population standard deviation.','', '| Configuration | TCP forward (Mbit/s) | TCP reverse (Mbit/s) | Received UDP (Mbit/s) | UDP loss (%) | Average RTT (ms) |','|---|---:|---:|---:|---:|---:|']
for c,u in zip(r['configs'],udps):
    assert len(c['tcp_fwd_mbps']['runs'])==len(c['tcp_rev_mbps']['runs'])==5
    c['udp_receiver_corrected']=u
    vals=[f"{c[k]['mean']:.1f} ± {c[k]['stdev']:.1f}" for k in ['tcp_fwd_mbps','tcp_rev_mbps']]
    lines.append(f"| {c['label']} | {vals[0]} | {vals[1]} | {u['received_mbps']:.3f} | {u['loss_pct']:.4f} | {c['ping_rtt_ms']['avg']:.3f} |")
t,b=r['configs'];lines+=['',f"Forward TCP reduction: {(1-t['tcp_fwd_mbps']['mean']/b['tcp_fwd_mbps']['mean'])*100:.2f}%. Reverse TCP reduction: {(1-t['tcp_rev_mbps']['mean']/b['tcp_rev_mbps']['mean'])*100:.2f}%.",f"Added average RTT: {t['ping_rtt_ms']['avg']-b['ping_rtt_ms']['avg']:.3f} ms.",'','## Packet-size sweep','', 'UDP offered load: 200 Mbit/s, 8 seconds per UDP payload size; one observation per size. Receiver-side measurements.','', '| UDP payload bytes | Sent Mbit/s | Received Mbit/s | Loss % | Received packets/s | Status |','|---:|---:|---:|---:|---:|---|' ]
for m in [x for x in measurements if x['experiment']==2]:
    if m['received_pps']==0:
        lines.append(f"| {m['payload_bytes']} | {m['sent_mbps']:.3f} | {m['received_mbps']:.3f} | N/A | 0 | No packets received |")
    elif m['received_mbps']=='':
        lines.append(f"| {m['payload_bytes']} | {m['sent_mbps']:.3f} | — | — | — | {m['error'] or 'No receiver result'} |")
    else:
        lines.append(f"| {m['payload_bytes']} | {m['sent_mbps']:.3f} | {m['received_mbps']:.3f} | {m['loss_pct']:.4f} | {m['received_pps']:.0f} | {'OK' if m['returncode']==0 else 'Nonzero exit'} |")
lines+=['','## Interpretation and limits','','These namespace measurements compare native software paths on one machine; they do not measure Pi performance or a physical Ethernet link. Baseline follows tunnel in a single session, without CPU pinning or frequency locking. Five TCP observations give within-session spread; UDP/RTT and sweep points do not have across-session uncertainty estimates.','', 'When sent throughput is below offered load, low received goodput alone does not establish tunnel saturation; sender pacing/generation limits may contribute. The sweep is a fixed-offered-load measurement, not a maximum-capacity search.','', 'At 1428-byte payload, iperf3 recorded one sender datagram and zero receiver packets. Its raw 0% loss field is not a valid delivery/loss conclusion; report loss as unavailable. This run establishes no delivery at that size, not sustained-load loss percentage.','', 'UDP payload plus 28 bytes of IPv4/UDP headers forms the inner IP packet. The 1400-byte payload fits the 1428-byte inner MTU; the 1428-byte payload exceeds the unfragmented boundary. Consult raw outcomes rather than assuming MTU behavior.','', 'The original experiment-1 summary uses iperf3 end.sum for UDP; the table here is corrected from the preserved end.sum_received fields. TCP values are unchanged. Experiment 2 ran with receiver-side extraction and received-packet-rate fixes.','', 'The module was compiled with GCC 14 against a GCC-15-built kernel; header warnings and successful build/load evidence are retained. Gateway module detection also required a one-line fix. See benchmark-fix.patch.','', 'See all-transfers.csv for every transfer, raw JSON for independent verification, README.md for reproduction, and environment.json for host metadata.']
(root/'REPORT.md').write_text('\n'.join(lines)+'\n')
(root/'experiment-1'/'benchmark-receiver-corrected.json').write_text(json.dumps(r,indent=2)+'\n')
print('\n'.join(lines))
