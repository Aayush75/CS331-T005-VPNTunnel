# Physical Pi-to-Pi Ethernet benchmark results

Two Raspberry Pi 5 gateways, native Linux 6.18.34+rpt-rpi-2712 (aarch64, 16 KiB pages), joined by a direct 1 Gbit/s full-duplex Ethernet cable. Wi-Fi carries SSH management only. Traffic originates and terminates on the Pis; CPU includes endpoint generation/receive work plus VPN processing.

Direct endpoints: 172.31.250.11 ↔ 172.31.250.12. VPN endpoints: 10.77.1.10 ↔ 10.77.2.10, routed through vpn0 and the same Ethernet link. Reserved gateway addresses (.1) are not test endpoints.

Five TCP runs per direction/configuration, 20 measured seconds each plus 2 omitted warm-up seconds. Single TCP stream; population standard deviation shown. UDP payload 1200 bytes, 10 seconds per point at 500/800/950 Mbit/s requested, both directions. Offloads were left at defaults and recorded per configuration. Direct ran before VPN in one session.

## TCP goodput, CPU and RTT

| Path | Direction | TCP received Mbit/s ± SD | Pi A host CPU % | Pi B host CPU % | Idle RTT ms | TCP-loaded RTT ms |
|---|---|---:|---:|---:|---:|---:|
| direct | forward | 936.49 ± 0.002 | 0.99 | 4.18 | 0.162 | 2.033 |
| direct | reverse | 936.43 ± 0.001 | 3.87 | 0.63 | 0.162 | 1.957 |
| tunnel | forward | 894.56 ± 0.029 | 25.57 | 18.16 | 0.197 | 4.215 |
| tunnel | reverse | 894.57 ± 0.021 | 18.65 | 25.03 | 0.197 | 4.080 |

## VPN useful-throughput reduction

- Forward: 4.48% reduction; VPN retains 95.52% of direct TCP goodput.
- Reverse: 4.47% reduction; VPN retains 95.53% of direct TCP goodput.

## CPU and thermal detail

| Path | Direction | Pi | Busy CPU equivalents ± SD | Softirq CPU equivalents | Busiest core window % | Peak sample core % | Maximum temperature C |
|---|---|---|---:|---:|---:|---:|---:|
| direct | forward | A | 0.04 ± 0.01 | 0.022 | 3.04 | 9.02 | 52.9 |
| direct | forward | B | 0.16 ± 0.01 | 0.062 | 10.62 | 27.93 | 51.2 |
| direct | reverse | A | 0.15 ± 0.01 | 0.054 | 8.35 | 25.46 | 56.2 |
| direct | reverse | B | 0.02 ± 0.01 | 0.010 | 1.47 | 4.67 | 51.2 |
| tunnel | forward | A | 1.02 ± 0.00 | 0.991 | 98.91 | 100.00 | 65.5 |
| tunnel | forward | B | 0.69 ± 0.02 | 0.444 | 55.02 | 61.57 | 62.2 |
| tunnel | reverse | A | 0.71 ± 0.01 | 0.464 | 57.01 | 62.49 | 67.8 |
| tunnel | reverse | B | 1.01 ± 0.00 | 0.982 | 96.26 | 98.43 | 64.5 |

## Idle background

| Path | Pi | Host CPU % | Busy CPU equivalents | Idle RTT ms | Ping sent / received |
|---|---|---:|---:|---:|---:|
| direct | A | 0.03 | 0.001 | 0.162 | 50 / 50 |
| direct | B | 0.03 | 0.001 | 0.160 | 50 / 50 |
| tunnel | A | 0.03 | 0.001 | 0.197 | 50 / 50 |
| tunnel | B | 0.03 | 0.001 | 0.190 | 50 / 50 |

## UDP load points

| Path | Direction | Requested Mbit/s | Actual sent Mbit/s | Received Mbit/s | Loss % | Pi A CPU % | Pi B CPU % | Target reached? |
|---|---|---:|---:|---:|---:|---:|---:|---|
| direct | forward | 500 | 499.99 | 499.98 | 0.00000 | 8.88 | 2.44 | yes (≥98%) |
| direct | reverse | 500 | 500.00 | 500.00 | 0.00000 | 1.28 | 15.02 | yes (≥98%) |
| direct | forward | 800 | 799.98 | 799.96 | 0.00000 | 13.83 | 5.01 | yes (≥98%) |
| direct | reverse | 800 | 800.00 | 800.00 | 0.00000 | 5.36 | 10.18 | yes (≥98%) |
| direct | forward | 950 | 947.84 | 947.79 | 0.00000 | 10.59 | 4.96 | yes (≥98%) |
| direct | reverse | 950 | 947.84 | 947.80 | 0.00000 | 4.34 | 9.78 | yes (≥98%) |
| tunnel | forward | 500 | 499.99 | 499.97 | 0.00192 | 4.36 | 4.96 | yes (≥98%) |
| tunnel | reverse | 500 | 500.00 | 499.99 | 0.00211 | 3.46 | 9.97 | yes (≥98%) |
| tunnel | forward | 800 | 799.98 | 799.95 | 0.00204 | 22.41 | 5.18 | yes (≥98%) |
| tunnel | reverse | 800 | 800.00 | 799.99 | 0.00132 | 6.68 | 22.61 | yes (≥98%) |
| tunnel | forward | 950 | 888.03 | 888.00 | 0.00130 | 25.80 | 7.53 | no (93.5%) |
| tunnel | reverse | 950 | 950.00 | 895.19 | 4.73885 | 5.94 | 23.47 | yes (≥98%) |

## TCP retransmissions and ping delivery

| Path | TCP direction | Total retransmissions (five runs) | Loaded ping sent / received (includes warm-up) |
|---|---|---:|---:|
| direct | forward | 0 | 1100 / 1100 |
| direct | reverse | 0 | 1099 / 1099 |
| tunnel | forward | 112 | 1095 / 1095 |
| tunnel | reverse | 121 | 1095 / 1095 |

TCP retransmissions are recovered by TCP; the count is not an application-data loss percentage. All raw counts remain in the JSON/CSV.

## Method and limits

- Loaded ping probes originate on Pi A for both TCP traffic directions; idle probes were recorded from both Pis. RTT statistics omit the TCP warm-up approximately; full-transfer ping delivery counts include it.
- CPU counters on both Pis were sampled every 0.5 seconds for the entire phase. Per-transfer windows use synchronized UTC timestamps; TCP windows exclude approximately the first 2 seconds. Boundary alignment has sampling/SSH/iperf startup uncertainty. Raw timestamps/counters are retained.
- Host busy % spans four logical CPUs on each Pi; one busy CPU equivalent means one busy CPU-second per wall second, without normalizing performance across architectures or operating frequencies. Busy excludes idle and iowait; guest fields are not double-counted. Per-core and softirq counters are included. Background is reported separately, not silently subtracted.
- Whole-host CPU includes generators, receive processing, controllers, kernel crypto/forwarding, instrumentation and background activity. Endpoint process CPU percentages in CSV use one-core scale and are already included in host CPU; do not add them.
- CPU frequencies/governors, thermal readings and throttling were recorded. Temperature sampling is every 0.5 seconds; throttling flags every 5 seconds and at each client completion.
- UDP target rates are payload rates. Encapsulation/headers consume physical link capacity too. If actual sender rate misses its target, low measured loss cannot establish support for that requested load.
- TCP retransmissions are retained in CSV and original JSON; they are not an application-data loss percentage. Idle/loaded ping loss must be read separately.
- One ordered session with five TCP observations per direction: SD is within-session spread, not across-session confidence intervals. No CPU pinning or frequency lock was applied.
- Lower loaded RTT while delivering less traffic does not prove a latency advantage at equal delivered work. Pi-local endpoints also do not exercise LAN-host forwarding in the same way as the separate laptop demonstration.

See validation.json, parameters.json, commands.json, all-transfers.csv, cpu-per-transfer.json, and raw/ for independent verification. No private keys or passwords are included.
