# Physical Pi-to-Pi experiment — 6 November 2026

Completed and validated: **20 TCP transfers and 12 UDP transfers**, with CPU/thermal
sampling on **both Pis throughout each configuration**. Both devices are native Pi 5s
with the same 1 Gbit/s direct Ethernet link. Wi-Fi is SSH management only.

## Start here

- [Report and methodology](REPORT.md)
- [Every transfer, CPU and RTT values (CSV)](all-transfers.csv)
- [TCP aggregate means/population SD](aggregates.json)
- [Per-transfer CPU summaries for both Pis and every core](cpu-per-transfer.json)
- [Completeness and control validation](validation.json)
- [TCP throughput figure](figures/pi-tcp-goodput.png)
- [CPU figure](figures/pi-tcp-cpu.png)
- [UDP actual sent/received rates](figures/pi-udp-goodput.png)
- [Idle/loaded RTT figure](figures/pi-rtt.png)

All figures also have PDF/SVG exports. Raw timestamps are UTC; the report/date label
uses Asia/Kolkata (6 November).

## Key findings

TCP goodput averaged **936.49/936.43 Mbit/s direct** and **894.56/894.57 Mbit/s VPN**
(forward/reverse). The VPN retained **95.52%/95.53%** of useful direct TCP throughput.

During VPN TCP, the transmitting Pi used about one busy CPU equivalent (~25% of its
four-core host), with a near-fully busy core. The receiving Pi used roughly 18% host
CPU. These totals include endpoint work and background activity, not only crypto.
The default ondemand governor/frequency behavior is retained in the raw samples.

Idle RTT from A averaged **0.162 ms direct** versus **0.197 ms VPN**. TCP-loaded RTT
averaged about **2.0 ms direct** versus **4.1–4.2 ms VPN**. Idle and loaded ping traces
are preserved, with no lost probes observed in these measurements.

Direct UDP reported zero loss in all six points. VPN UDP at 500/800 Mbit/s delivered
nearly the requested payload rates, with **0.0013–0.0021%** reported loss. At the
950 Mbit/s target, forward sent only **888.03 Mbit/s** (target not reached); reverse
sent **950 Mbit/s**, received **895.19 Mbit/s** and reported **4.73885% loss**. Do not
interpret the forward low loss as proof of support for 950 Mbit/s offered payload.

TCP reported **0 retransmissions direct** and **233 through VPN**, recovered by TCP.
These are retransmission counts, not an application-data loss percentage. No recorded
throttling occurred. Sampled temperatures remained below 70 C (client completion
readings and continuous samples may differ slightly in timing).

## Evidence layout

- `parameters.json`: exact host addresses, durations, rates, monitoring and phase order.
- `commands.json`: every controller SSH command, exit status, stdout/stderr and timestamp.
- `results.json`: exact per-transfer summaries, source timing windows and client telemetry.
- `run.log`: experiment progress.
- `raw/direct/pi-a`, `raw/direct/pi-b`, `raw/tunnel/pi-a`, `raw/tunnel/pi-b`:
  phase metadata, original 0.5-second CPU/softirq/thermal JSONL, idle windows/pings,
  and original per-transfer iperf JSON, loaded ping and exact command/timestamps.
- `raw/*/pi-b/server.log`: persistent server text log. The clients retain the server
  output in their original iperf JSON as well.
- `raw/tunnel/*/controller.log`: controller establishment/lease logs.
- `build-provenance/`: prior successful native release build logs and reboot readiness.
  The binaries were reused unchanged; fresh metadata records their SHA256 values.
- `tooling/`: the exact measuring/analysis/plotting tools, without credentials.
- `SHA256SUMS`: checksums for every evidence file.

The base source archive, source-changes.patch and source-provenance.json retain the source lineage. The prepared Pi operating guide and wrapper/service sources are also included under tooling/.

Private identities remain on the Pis in root-only `/etc/vpntunnel`. No passwords or
private keys are included. The setup/old-source cleanup evidence remains separate.

## Reproduce

Use the prepared Pi setup described in `code/docs/pi-benchmark.md` in the repository.
Check a direct gigabit link, correct endpoint aliases (.10, not reserved .1), working
campus Wi-Fi SSH, and matching native kernel/module/controller binaries. Install
`pi_bench_agent.py` and `cpu_monitor.py` from this bundle into each checkout's
`code/tools/`. The local driver uses these paths on each Pi:
`/home/cn/CS331-T005-VPNTunnel/code/tools/pi_bench_agent.py`.

Establish authenticated SSH control sessions on the laptop first (substitute current
Wi-Fi addresses if DHCP changed):

```
ssh -M -S /tmp/vpt-pi-a-wifi.sock -o ControlPersist=1h -fN cn@10.7.45.18
ssh -M -S /tmp/vpt-pi-b-wifi.sock -o ControlPersist=1h -fN cn@10.7.16.136
python3 code/tools/bench_pi_pair.py --output report-results/new-pi-run
```

The driver securely prompts for the common Pi sudo password and never saves it. CLI
options support different management addresses and control-socket paths. Use a fresh
output directory. It runs direct first, then VPN; records idle CPU/RTT; performs all
TCP/UDP transfers; records VPN-off guards; and stops both VPNs/modules afterward.

Only lightweight command summaries return over Wi-Fi during traffic tests. Once the
driver finishes, copy the four remote phase folders (`direct/pi-a`, `direct/pi-b`,
`tunnel/pi-a`, `tunnel/pi-b`) under the local output's `raw/`, preserving that layout.
The remote root is printed at completion and stored in `parameters.json`.
This run's remote root is `/home/cn/results/pi-pair-1793915902`.

```
python3 code/tools/summarize_pi_pair.py report-results/new-pi-run
python3 code/tools/validate_pi_pair.py report-results/new-pi-run
python3 code/tools/plot_pi_pair.py report-results/new-pi-run
```

Measurement/analysis tools use Python standard library; plotting uses matplotlib.
All actual runs and analysis were completed successfully for this evidence bundle.
Both Pis were returned to VPN-off idle state, with far-LAN unreachable guards restored.
The separate Wi-Fi/laptop LAN demo and Pi namespace backup lane are not claimed here.
