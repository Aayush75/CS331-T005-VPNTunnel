The first attempt completed 48 transfers: 32 unrestricted transfers and 16 direct-path
transfers at 100 Mbit/s. Switching from direct forwarding back to VPN failed before
any tunnel measurement because the direct far-LAN static routes conflicted with the
VPN route creation. The finally block removed that attempt's namespaces.

The resumed harness explicitly removes the two far-LAN direct routes before starting
the VPN. It loads completed records from results.json, skips completed phases and
labels, and preserves every existing measurement. The remaining phases run in a fresh
fixture. Original attempt log and initial/resumed harness sources are retained.
No completed transfer was rerun to select a better outcome.
