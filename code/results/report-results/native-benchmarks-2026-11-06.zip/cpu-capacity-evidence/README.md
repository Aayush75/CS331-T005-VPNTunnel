# Native CPU and matched-capacity benchmark evidence

This bundle adds whole-host/per-core CPU instrumentation and controlled bidirectional
link capacities to the original unrestricted measurements. It runs directly on the
native Linux host, using the repository's real controller, kernel module and N1
network-namespace topology. It does not use a VM.

## Read first

- `REPORT.md`: interpreted TCP/UDP/RTT and CPU tables, methodology and limits.
- `all-transfers.csv`: every transfer with receiver-side goodput, loss, CPU, endpoint
  process CPU, background CPU and RTT fields. No failed observation is filtered out.
- `aggregates.json`: five-run TCP means and population standard deviations.
- `validation.json`: completeness and configuration validation.
- `figures/`: report figures in PNG, PDF and SVG (created after measurements finish).
- `run/parameters.json`: exact benchmark settings.
- `run/results.json`: complete per-transfer summaries, including all per-core CPU summaries.
- `run/<phase>/<path>/<transfer>/`: original iperf JSON, exact command/exit status,
  0.5-second CPU samples, loaded ping, server log and before/after qdisc counters.
- `run/<phase>/<path>/cpu-idle*` and `ping-idle.json`: background and idle RTT evidence.
- `run/metadata/`: offload and qdisc snapshots; the command log also records link MTUs.
- `run/commands.json`: namespace/setup/shaping/inspection/cleanup commands and output.
- `attempt-1.log`, `run.log`, `RESUME-NOTE.md`: transparent route-transition failure
  and checkpoint resume, preserving all completed transfers.
- `environment.json`: CPU, kernel, virtualization detection, governor, AC power and versions.
- `source-fixes.patch` and included Python sources: changes and reproducibility tooling.
- `SHA256SUMS`: checksums of all evidence files.

The original `native-benchmark-results.zip` remains the separate unrestricted software
ceiling evidence. Its raw measurements are not replaced by these instrumented repeats.
The same built module and controller are reused; their build logs and GCC-14 versus
GCC-15-kernel compiler limitation are in that original bundle.

## Design

The unrestricted CPU repeat uses default offloads. It includes five TCP runs per
path/direction, a 100 Mbit/s UDP point per path, and the ten-size tunnel UDP sweep.
All have system/per-core CPU monitoring; TCP transfers also have loaded ping.

For each controlled capacity (100, 500, 1000, 2500 Mbit/s), each path has:

- Five received TCP goodput runs per direction; 15 measured seconds plus 2 omitted warm-up.
- A 5-second CPU background observation and 50 idle ping probes.
- Timestamped ping during every TCP transfer, summarized after the initial 2 seconds.
- UDP at 50%, 80%, 95% offered payload rates, in both directions, 8 seconds per point,
  1200-byte UDP payload. CPU monitoring accompanies every transfer.

Both underlay bridge egress ports carry a matching TBF qdisc, one for each direction.
Shaping is on the outer transport, so tunnel headers consume the link budget. Burst
is 1 ms at capacity (minimum 16 KB), queue limit expressed as 20 ms latency,
accounting overhead is 24 bytes and minimum packet unit is 64 bytes.
TSO/GSO/GRO are disabled on all experiment veth interfaces for both controlled paths.
Only namespace-local interfaces are changed. All MTUs/offload settings are recorded.
Configuration order alternates by capacity. The 100 Mbit/s baseline and tunnel ran
across the documented checkpoint resume; the remaining cases continue in that fixture.

## CPU interpretation

Busy percentage is whole-host busy ticks divided by total ticks, excluding idle and
iowait. Core-equivalents are busy CPU-seconds divided by wall seconds. One equivalent
means one fully busy logical CPU, without normalizing performance between this CPU's
heterogeneous cores. Guest counters are not double-counted. Per-core system/softirq
CPU time and NET_RX/NET_TX softirq counts are retained.

CPU includes both gateways, both endpoints, iperf pacing, instrumentation and unrelated
background work. Idle background is shown separately, not silently subtracted. Endpoint
process CPU is in a different scale: iperf's 100% corresponds to one busy CPU.
UDP pacing can consume one CPU even below link capacity. Compare CPU at similar measured
delivered rates, not merely equal offered rate, and do not call these values VPN-only CPU.

## Reproduce

From `code/`, with the same built binaries and prerequisites:

```
sudo VPTCTL="$PWD/control/target/release/vptctl" \
  python3 tools/bench_capacity_cpu.py --output results/new-cpu-capacity-evidence/run
python3 tools/summarize_capacity_cpu.py results/new-cpu-capacity-evidence
python3 tools/validate_capacity_cpu.py results/new-cpu-capacity-evidence
python3 tools/plot_capacity_cpu.py results/new-cpu-capacity-evidence
```

Plotting alone requires matplotlib; the measurement and summary tools use Python's
standard library. Use a new output directory. `--resume` reloads completed labels from
`results.json`; do not change run parameters during a resume. The initial and resumed
harness source versions used here are retained, along with the current repository tools.

## Pi experiments

CPU capture is required on both Pi gateways for every remaining physical demo/benchmark.
Run `python3 tools/cpu_monitor.py --output results/pi-a-cpu --seconds 3600` (distinct
paths on both devices), then Ctrl-C after the experiment. Capture a separate idle
observation, align experiment start/end UTC timestamps, and record temperature,
throttling, governor, Wi-Fi conditions and Ethernet speed. Capture laptop CPU separately
when OS tooling/access permits. No Pi result is claimed in this native-host bundle.

Figures were rendered with Matplotlib 3.6.3 after all traffic/CPU measurements completed. Plot dependency installation occurred afterward, not during the measured workload.
