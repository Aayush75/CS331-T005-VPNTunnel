# Native CPU and matched-capacity results

Status: COMPLETE. Completed 160 of 160 scheduled transfers.

Native Intel Core Ultra 7 165H, 22 logical CPUs, Linux 6.18.34-061834-generic. Whole-host /proc/stat sampled every 0.5 seconds; raw per-core counters and NET_RX/NET_TX softirq counts retained. Busy excludes idle and iowait. CPU includes both gateways, both endpoints, instrumentation and background host activity. It is not VPN-exclusive CPU.

TCP: five independent 15-second measured transfers in each direction, with 2-second warm-up omitted; CPU and loaded RTT omit the initial 2 seconds approximately. Every capacity/path has a 5-second idle CPU observation and 50-packet idle RTT. UDP: 8 seconds per rate and direction, 1200-byte payload for controlled paths.

Controlled underlay: TBF on both underlay bridge egress ports, shaping outer transport including tunnel headers. Burst is 1 ms of capacity (minimum 16 KB), queue latency limit 20 ms, accounting overhead 24 bytes and minimum packet unit 64 bytes. This emulates a full-duplex capacity with bounded queues, without added propagation delay. qdisc configuration/counters are retained for every transfer.

Unrestricted CPU repeats retain default offloads. Controlled comparisons disable TSO/GSO/GRO on all virtual Ethernet interfaces for both paths; therefore controlled-versus-unrestricted differences include offload changes as well as shaping. The original unrestricted evidence remains separate. Mode order alternates by capacity.

## TCP goodput and whole-host CPU

| Capacity Mbit/s | Path | Direction | Runs | Received Mbit/s ± SD | Host busy % | Busy CPU equivalents | Softirq CPU equivalents | Idle RTT ms | Loaded RTT ms |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| unrestricted | baseline | forward | 5 | 49802.34 ± 1728.37 | 8.48 | 1.86 | 0.611 | 0.112 | 0.056 |
| unrestricted | baseline | reverse | 5 | 48423.91 ± 374.92 | 8.40 | 1.84 | 0.616 | 0.112 | 0.075 |
| unrestricted | tunnel | forward | 5 | 2302.74 ± 63.19 | 5.67 | 1.24 | 1.002 | 0.181 | 0.081 |
| unrestricted | tunnel | reverse | 5 | 2195.16 ± 5.49 | 5.64 | 1.24 | 1.019 | 0.181 | 0.080 |
| 100 | baseline | forward | 5 | 93.84 ± 0.00 | 0.98 | 0.22 | 0.062 | 0.120 | 17.897 |
| 100 | baseline | reverse | 5 | 93.87 ± 0.02 | 1.01 | 0.22 | 0.062 | 0.120 | 17.917 |
| 100 | tunnel | forward | 5 | 89.42 ± 0.00 | 1.48 | 0.32 | 0.128 | 0.108 | 17.936 |
| 100 | tunnel | reverse | 5 | 89.41 ± 0.00 | 1.38 | 0.30 | 0.130 | 0.108 | 17.792 |
| 500 | baseline | forward | 5 | 470.72 ± 0.01 | 1.65 | 0.36 | 0.171 | 0.105 | 18.021 |
| 500 | baseline | reverse | 5 | 470.74 ± 0.00 | 1.70 | 0.37 | 0.169 | 0.105 | 18.048 |
| 500 | tunnel | forward | 5 | 447.24 ± 0.03 | 3.04 | 0.67 | 0.411 | 0.195 | 17.355 |
| 500 | tunnel | reverse | 5 | 447.19 ± 0.03 | 2.85 | 0.62 | 0.407 | 0.195 | 17.857 |
| 1000 | baseline | forward | 5 | 941.49 ± 0.04 | 2.90 | 0.63 | 0.323 | 0.110 | 17.929 |
| 1000 | baseline | reverse | 5 | 941.46 ± 0.03 | 2.75 | 0.60 | 0.323 | 0.110 | 17.944 |
| 1000 | tunnel | forward | 5 | 893.94 ± 0.45 | 4.50 | 0.99 | 0.720 | 0.144 | 13.734 |
| 1000 | tunnel | reverse | 5 | 893.74 ± 0.52 | 4.36 | 0.95 | 0.719 | 0.144 | 14.395 |
| 2500 | baseline | forward | 5 | 2353.89 ± 0.05 | 5.10 | 1.11 | 0.646 | 0.110 | 10.555 |
| 2500 | baseline | reverse | 5 | 2353.86 ± 0.11 | 4.94 | 1.08 | 0.644 | 0.110 | 9.380 |
| 2500 | tunnel | forward | 5 | 1823.05 ± 24.09 | 5.70 | 1.25 | 0.995 | 0.170 | 0.073 |
| 2500 | tunnel | reverse | 5 | 1861.08 ± 10.71 | 5.54 | 1.22 | 0.989 | 0.170 | 0.074 |

## CPU detail (five TCP runs per row)

| Capacity | Path | Direction | Host busy % ± SD | CPU equivalents ± SD | Busiest CPU window % | Peak CPU sample % (mean) | Idle host busy % |
|---|---|---|---:|---:|---:|---:|---:|
| unrestricted | baseline | forward | 8.48 ± 0.48 | 1.86 ± 0.11 | 71.57 | 100.00 | 0.54 |
| unrestricted | baseline | reverse | 8.40 ± 0.28 | 1.84 ± 0.06 | 87.41 | 100.00 | 0.54 |
| unrestricted | tunnel | forward | 5.67 ± 0.23 | 1.24 ± 0.05 | 75.05 | 100.00 | 0.67 |
| unrestricted | tunnel | reverse | 5.64 ± 0.19 | 1.24 ± 0.04 | 84.90 | 100.00 | 0.67 |
| 100 | baseline | forward | 0.98 ± 0.25 | 0.22 ± 0.05 | 4.82 | 37.82 | 0.45 |
| 100 | baseline | reverse | 1.01 ± 0.24 | 0.22 ± 0.05 | 3.86 | 54.35 | 0.45 |
| 100 | tunnel | forward | 1.48 ± 0.38 | 0.32 ± 0.08 | 6.32 | 37.67 | 1.74 |
| 100 | tunnel | reverse | 1.38 ± 0.09 | 0.30 ± 0.02 | 6.08 | 66.73 | 1.74 |
| 500 | baseline | forward | 1.65 ± 0.21 | 0.36 ± 0.05 | 7.28 | 34.48 | 0.61 |
| 500 | baseline | reverse | 1.70 ± 0.35 | 0.37 ± 0.08 | 7.76 | 83.33 | 0.61 |
| 500 | tunnel | forward | 3.04 ± 0.50 | 0.67 ± 0.11 | 13.54 | 55.86 | 0.31 |
| 500 | tunnel | reverse | 2.85 ± 0.15 | 0.62 ± 0.03 | 13.31 | 60.53 | 0.31 |
| 1000 | baseline | forward | 2.90 ± 0.49 | 0.63 ± 0.11 | 12.41 | 59.80 | 1.63 |
| 1000 | baseline | reverse | 2.75 ± 0.17 | 0.60 ± 0.04 | 12.07 | 52.26 | 1.63 |
| 1000 | tunnel | forward | 4.50 ± 0.23 | 0.99 ± 0.05 | 24.37 | 68.65 | 1.78 |
| 1000 | tunnel | reverse | 4.36 ± 0.25 | 0.95 ± 0.06 | 23.15 | 100.00 | 1.78 |
| 2500 | baseline | forward | 5.10 ± 0.45 | 1.11 ± 0.10 | 36.55 | 78.88 | 1.46 |
| 2500 | baseline | reverse | 4.94 ± 0.44 | 1.08 ± 0.10 | 32.18 | 84.14 | 1.46 |
| 2500 | tunnel | forward | 5.70 ± 0.36 | 1.25 ± 0.08 | 61.98 | 100.00 | 0.38 |
| 2500 | tunnel | reverse | 5.54 ± 0.22 | 1.22 ± 0.05 | 67.98 | 100.00 | 0.38 |

## Matched-capacity VPN goodput reduction

| Capacity Mbit/s | Forward reduction % | Reverse reduction % |
|---:|---:|---:|
| 100 | 4.70 | 4.75 |
| 500 | 4.99 | 5.00 |
| 1000 | 5.05 | 5.07 |
| 2500 | 22.55 | 20.93 |

## UDP received throughput, loss and CPU

| Capacity | Path | Direction | Offered Mbit/s | Payload B | Sent Mbit/s | Received Mbit/s | Loss % | Host busy % | CPU equivalents |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| unrestricted | tunnel | forward | 100 | 1376 | 99.992 | 99.991 | 0.00000 | 4.95 | 1.08 |
| unrestricted | tunnel | forward | 200 | 64 | 77.903 | 77.832 | 0.08773 | 7.02 | 1.52 |
| unrestricted | tunnel | forward | 200 | 128 | 150.907 | 150.851 | 0.03350 | 7.29 | 1.58 |
| unrestricted | tunnel | forward | 200 | 256 | 199.966 | 199.932 | 0.01485 | 6.68 | 1.45 |
| unrestricted | tunnel | forward | 200 | 512 | 199.974 | 199.912 | 0.02995 | 8.55 | 1.91 |
| unrestricted | tunnel | forward | 200 | 768 | 199.972 | 199.968 | 0.00000 | 4.87 | 1.06 |
| unrestricted | tunnel | forward | 200 | 1024 | 199.970 | 199.965 | 0.00000 | 4.93 | 1.07 |
| unrestricted | tunnel | forward | 200 | 1200 | 199.972 | 199.968 | 0.00000 | 6.56 | 1.45 |
| unrestricted | tunnel | forward | 200 | 1300 | 199.972 | 199.969 | 0.00000 | 5.29 | 1.15 |
| unrestricted | tunnel | forward | 200 | 1400 | 199.971 | 199.966 | 0.00000 | 4.91 | 1.07 |
| unrestricted | tunnel | forward | 200 | 1428 | 0.001 | 0.000 | N/A (no receiver packets) | 0.35 | 0.08 |
| unrestricted | baseline | forward | 100 | 1376 | 99.991 | 99.990 | 0.00000 | 4.98 | 1.09 |
| 100 | baseline | forward | 50.0 | 1200 | 49.992 | 49.991 | 0.00000 | 4.99 | 1.09 |
| 100 | baseline | reverse | 50.0 | 1200 | 49.999 | 50.000 | 0.00000 | 4.91 | 1.08 |
| 100 | baseline | forward | 80.0 | 1200 | 79.987 | 79.986 | 0.00000 | 4.90 | 1.07 |
| 100 | baseline | reverse | 80.0 | 1200 | 80.001 | 79.991 | 0.00000 | 6.16 | 1.35 |
| 100 | baseline | forward | 95.0 | 1200 | 94.985 | 94.788 | 0.00000 | 7.53 | 1.68 |
| 100 | baseline | reverse | 95.0 | 1200 | 94.990 | 94.789 | 0.00000 | 6.40 | 1.40 |
| 100 | tunnel | forward | 50.0 | 1200 | 49.992 | 49.991 | 0.00000 | 5.32 | 1.16 |
| 100 | tunnel | reverse | 50.0 | 1200 | 50.000 | 49.994 | 0.00000 | 6.53 | 1.43 |
| 100 | tunnel | forward | 80.0 | 1200 | 79.987 | 79.952 | 0.00000 | 4.88 | 1.07 |
| 100 | tunnel | reverse | 80.0 | 1200 | 79.999 | 79.995 | 0.00000 | 7.56 | 1.70 |
| 100 | tunnel | forward | 95.0 | 1200 | 94.984 | 89.688 | 5.33616 | 6.71 | 1.48 |
| 100 | tunnel | reverse | 95.0 | 1200 | 95.000 | 89.689 | 5.32202 | 5.05 | 1.11 |
| 500 | tunnel | forward | 250.0 | 1200 | 249.963 | 249.954 | 0.00048 | 5.25 | 1.14 |
| 500 | tunnel | reverse | 250.0 | 1200 | 249.984 | 249.977 | 0.00000 | 5.91 | 1.31 |
| 500 | tunnel | forward | 400.0 | 1200 | 399.946 | 399.938 | 0.00000 | 5.03 | 1.09 |
| 500 | tunnel | reverse | 400.0 | 1200 | 399.980 | 399.969 | 0.00000 | 5.84 | 1.29 |
| 500 | tunnel | forward | 475.0 | 1200 | 474.936 | 448.213 | 5.38605 | 6.76 | 1.48 |
| 500 | tunnel | reverse | 475.0 | 1200 | 474.975 | 448.454 | 5.32207 | 5.30 | 1.16 |
| 500 | baseline | forward | 250.0 | 1200 | 249.962 | 249.955 | 0.00000 | 5.96 | 1.30 |
| 500 | baseline | reverse | 250.0 | 1200 | 249.986 | 249.995 | 0.00000 | 5.03 | 1.10 |
| 500 | baseline | forward | 400.0 | 1200 | 399.938 | 399.930 | 0.00000 | 4.93 | 1.07 |
| 500 | baseline | reverse | 400.0 | 1200 | 399.993 | 399.992 | 0.00000 | 4.86 | 1.06 |
| 500 | baseline | forward | 475.0 | 1200 | 474.923 | 473.934 | 0.00000 | 5.69 | 1.24 |
| 500 | baseline | reverse | 475.0 | 1200 | 474.951 | 473.943 | 0.00000 | 5.34 | 1.17 |
| 1000 | baseline | forward | 500.0 | 1200 | 499.927 | 499.910 | 0.00000 | 4.90 | 1.06 |
| 1000 | baseline | reverse | 500.0 | 1200 | 499.966 | 499.952 | 0.00000 | 7.12 | 1.59 |
| 1000 | baseline | forward | 800.0 | 1200 | 799.888 | 799.508 | 0.04650 | 4.99 | 1.08 |
| 1000 | baseline | reverse | 800.0 | 1200 | 799.991 | 799.974 | 0.00000 | 4.88 | 1.06 |
| 1000 | baseline | forward | 950.0 | 1200 | 949.865 | 947.022 | 0.08994 | 7.43 | 1.62 |
| 1000 | baseline | reverse | 950.0 | 1200 | 949.988 | 947.789 | 0.01023 | 6.14 | 1.34 |
| 1000 | tunnel | forward | 500.0 | 1200 | 499.936 | 499.920 | 0.00048 | 6.59 | 1.45 |
| 1000 | tunnel | reverse | 500.0 | 1200 | 499.985 | 499.966 | 0.00000 | 5.74 | 1.26 |
| 1000 | tunnel | forward | 800.0 | 1200 | 799.950 | 799.923 | 0.00015 | 6.38 | 1.39 |
| 1000 | tunnel | reverse | 800.0 | 1200 | 799.985 | 799.827 | 0.01844 | 6.50 | 1.42 |
| 1000 | tunnel | forward | 950.0 | 1200 | 949.931 | 895.686 | 5.46275 | 6.29 | 1.37 |
| 1000 | tunnel | reverse | 950.0 | 1200 | 949.989 | 896.369 | 5.37720 | 9.64 | 2.20 |
| 2500 | tunnel | forward | 1250.0 | 1200 | 1186.271 | 1185.664 | 0.04795 | 6.60 | 1.43 |
| 2500 | tunnel | reverse | 1250.0 | 1200 | 1249.184 | 1249.192 | 0.00000 | 9.81 | 2.23 |
| 2500 | tunnel | forward | 2000.0 | 1200 | 1147.832 | 1147.097 | 0.06074 | 7.64 | 1.66 |
| 2500 | tunnel | reverse | 2000.0 | 1200 | 1238.229 | 1237.379 | 0.06876 | 6.23 | 1.36 |
| 2500 | tunnel | forward | 2375.0 | 1200 | 1170.784 | 1170.673 | 0.00625 | 6.81 | 1.48 |
| 2500 | tunnel | reverse | 2375.0 | 1200 | 1241.358 | 1241.124 | 0.01932 | 5.94 | 1.30 |
| 2500 | baseline | forward | 1250.0 | 1200 | 1249.860 | 1248.508 | 0.10589 | 10.83 | 2.46 |
| 2500 | baseline | reverse | 1250.0 | 1200 | 1249.912 | 1249.750 | 0.01391 | 4.94 | 1.07 |
| 2500 | baseline | forward | 2000.0 | 1200 | 1999.883 | 1999.161 | 0.03414 | 6.74 | 1.44 |
| 2500 | baseline | reverse | 2000.0 | 1200 | 1999.966 | 1999.921 | 0.00402 | 6.08 | 1.32 |
| 2500 | baseline | forward | 2375.0 | 1200 | 2374.591 | 2368.464 | 0.03815 | 9.73 | 2.09 |
| 2500 | baseline | reverse | 2375.0 | 1200 | 2374.981 | 2368.111 | 0.03904 | 6.63 | 1.44 |

## UDP targets not reached

Requested payload rate is not the same as actual offered traffic. These observations have sender throughput below 98% of the target; they cannot establish loss at the full requested load.

| Point | Requested Mbit/s | Actual sent Mbit/s | Target achieved % |
|---|---:|---:|---:|
| unrestricted/packet-sweep/udp-64 | 200 | 77.903 | 38.95 |
| unrestricted/packet-sweep/udp-128 | 200 | 150.907 | 75.45 |
| unrestricted/packet-sweep/udp-1428 | 200 | 0.001 | 0.00 |
| capacity-2500/tunnel/udp-0.5-forward | 1250.0 | 1186.271 | 94.90 |
| capacity-2500/tunnel/udp-0.8-forward | 2000.0 | 1147.832 | 57.39 |
| capacity-2500/tunnel/udp-0.8-reverse | 2000.0 | 1238.229 | 61.91 |
| capacity-2500/tunnel/udp-0.95-forward | 2375.0 | 1170.784 | 49.30 |
| capacity-2500/tunnel/udp-0.95-reverse | 2375.0 | 1241.358 | 52.27 |

## Limits and interpretation

- Peak CPU sample usage is the busiest per-core interval at the 0.5-second sampling cadence; window averages can hide scheduler migration between cores. It is not an instantaneous hardware utilization counter.
- A low whole-host percentage can hide one saturated core; per-core summaries and softirq CPU are included. CPU equivalents express busy CPU-seconds per wall second; one equivalent is one fully busy logical CPU, not a physical-core performance normalization.
- At UDP 50%/80%/95%, compare CPU only where measured received goodput is similar. Offered load alone does not prove equal delivered work. For small packets, a low sender rate can limit received goodput.
- iperf3 UDP pacing can consume close to one busy CPU even at low rates. Endpoint process CPU is included in CSV (100% means one CPU), and raw JSON retains endpoint user/system splits. Endpoint CPU is already included in whole-host CPU; do not add the percentages together. Process counters do not isolate all kernel forwarding/crypto work.
- CPU background observations are reported separately. They are not subtracted automatically and do not isolate unrelated activity during transfers.
- Lower loaded RTT at a lower delivered throughput does not establish an intrinsic latency advantage. Interpret the 2.5 Gbit/s VPN RTT alongside its below-capacity goodput.
- RTT under load includes queueing at the specified 20 ms qdiscs. It is specific to this queue configuration, not physical network propagation.
- These are native namespace measurements, not physical-network or Pi measurements. Qdisc limits are software link emulation. No CPU pinning or frequency lock was applied. Five runs provide within-session population SD, not across-session confidence intervals.
- A UDP point with zero received packets has unavailable loss percentage even if iperf reports zero. No failed transfer is silently dropped.
- Original results remain in native-benchmark-results.zip. Build/compiler limitations and source fixes remain documented there; this run reuses the same binaries.

See all-transfers.csv, aggregates.json and run/ for exact parameters, per-transfer JSON, CPU samples, idle/loaded ping, MTU/offload records, qdisc counters and commands.
