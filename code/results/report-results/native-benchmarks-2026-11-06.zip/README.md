# Native hardware benchmark evidence — 6 November 2026

Results were measured on this native Intel Core Ultra 7 165H system, Linux 6.18.34-061834-generic. No VM was used. Pi hardware results will be a separate experiment.

[Complete TA evidence archive](native-benchmarks-2026-11-06.zip) · [Detailed CPU/capacity report](CPU-and-capacity-report.md) · [All 160 instrumented transfers (CSV)](all-transfers.csv)

The archive preserves the original unrestricted results and the new CPU-instrumented unrestricted repeat, packet-size CPU sweep, and matched bidirectional 100/500/1000/2500 Mbit/s comparisons. It includes raw transfer JSON, 0.5-second system/per-core CPU counters, idle/loaded ping, MTUs/offloads, qdisc settings/counters, logs, source/tooling, fixes, validation and checksums.

## Matched-link TCP results

Mean received TCP goodput in Mbit/s. Each direction/path has five 15-second measured runs after a 2-second omitted warm-up. Controlled paths use identical outer-link shaping with TSO/GSO/GRO disabled.

| Link Mbit/s | Direct forward / reverse | VPN forward / reverse | Reduction forward / reverse |
|---:|---:|---:|---:|
| 100 | 93.84 / 93.87 | 89.42 / 89.41 | 4.70% / 4.75% |
| 500 | 470.72 / 470.74 | 447.24 / 447.19 | 4.99% / 5.00% |
| 1000 | 941.49 / 941.46 | 893.94 / 893.74 | 5.05% / 5.07% |
| 2500 | 2353.89 / 2353.86 | 1823.05 / 1861.08 | 22.55% / 20.93% |

![Matched-capacity received TCP goodput](capacity-goodput.png)

## CPU and interpretation

At the 1 Gbit/s limit, forward TCP used 2.90% whole-host CPU for direct forwarding and 4.50% for VPN (approximately 0.63 and 0.99 busy logical-CPU equivalents). These include both gateways, endpoints, instrumentation and background activity; they are not VPN-exclusive CPU. The detailed report includes per-core, peak-sample, softirq and idle CPU evidence for every phase.

![Whole-host CPU during matched TCP transfers](capacity-cpu.png)

The original unrestricted run remains a separate software-ceiling measurement. Controlled-lane differences include disabled offloads; do not combine the lanes as though only link rate changed. At high UDP targets some sender rates fall short: use actual sent/received rates and the explicit target-shortfall table, not requested load alone. The oversized 1428-byte UDP payload had no delivery, with loss percentage unavailable.

An initial route-transition setup failure was fixed and the run resumed from its 48 completed transfers without overwriting results. Validation passed all 160 unique transfers and matched shaping/offload checks. Namespaces were removed and the module unloaded with zero tracked objects.

## Files and reproduction

The ZIP contains `original-unrestricted/native-benchmark-results.zip` (the preserved original bundle) and `cpu-capacity-evidence/` (new full evidence). Start with each bundle's README. New runtime tools are in `code/tools/`, with copies included in the archive. `cpu_monitor.py` is also ready for both Pi gateways; capture CPU for every remaining physical experiment.

This directory is not covered by the repository's `code/results/` ignore rule, so it can be included in the submission. Files are saved locally; no commit or remote upload has been performed.
