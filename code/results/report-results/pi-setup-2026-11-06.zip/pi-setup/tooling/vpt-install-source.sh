#!/bin/bash
set -euo pipefail
cd /home/cn
if [ -f /tmp/vpt-arm64-rust-1.93.1.tar.gz ]; then
 tar xzf /tmp/vpt-arm64-rust-1.93.1.tar.gz -C /home/cn
 mkdir -p .cargo/bin
 for name in cargo rustc rustdoc rustfmt cargo-fmt cargo-clippy clippy-driver rust-analyzer rust-gdb rust-gdbgui rust-lldb; do ln -sf rustup ".cargo/bin/$name"; done
fi
export PATH=/home/cn/.cargo/bin:/usr/sbin:/usr/bin:/sbin:/bin
rustup default 1.93.1-aarch64-unknown-linux-gnu
if ! grep -q '.cargo/env' /home/cn/.profile; then printf '\n[ ! -f "$HOME/.cargo/env" ] || . "$HOME/.cargo/env"\n' >> /home/cn/.profile; fi
cat > /home/cn/.cargo/env <<'EOF'
case ":${PATH}:" in *:"$HOME/.cargo/bin":*) ;; *) export PATH="$HOME/.cargo/bin:$PATH" ;; esac
EOF
git clone /tmp/vpt-final-base.bundle /home/cn/CS331-T005-VPNTunnel
git -C /home/cn/CS331-T005-VPNTunnel remote set-url origin https://github.com/Aayush75/CS331-T005-VPNTunnel.git
tar xzf /tmp/vpt-final-source.tar.gz -C /home/cn/CS331-T005-VPNTunnel
mkdir -p /home/cn/.local/share/vpt-build
tar xzf /tmp/vpt-final-vendor.tar.gz -C /home/cn/.local/share/vpt-build
mkdir -p /home/cn/CS331-T005-VPNTunnel/.cargo
cat > /home/cn/CS331-T005-VPNTunnel/.cargo/config.toml <<'EOF'
[source.crates-io]
replace-with = "vendored-sources"
[source.vendored-sources]
directory = "/home/cn/.local/share/vpt-build/vendor"
[net]
offline = true
EOF
cd /home/cn/CS331-T005-VPNTunnel
python3 - <<'PY'
import json,hashlib
from pathlib import Path
m=json.loads(Path('SOURCE-MANIFEST.json').read_text())
for name,digest in m['sha256'].items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
print('Final source manifest verified:',len(m['sha256']),'files; base',m['base_commit'])
PY
cd code
./scripts/pi-build.sh
printf 'Native build completed: '; date -u --iso-8601=seconds
