from pathlib import Path
import os,re,subprocess
keys={'a':'ee3d33994f0b73f41b5fa2a27e73268a9ba88a969bb3d09abd72dd01ef41b060','b':'d5b0ce0528d86953eaa464c2e233f56f51df0a1eacf1b036d92f35e8f0437803'}
repo=Path('/home/cn/CS331-T005-VPNTunnel')
side=Path('/etc/vpntunnel/side').read_text().strip()
for s,peer in [('a','b'),('b','a')]:
 p=repo/'code/infra/gateway'/f'demo-pi-{s}.toml'
 text=p.read_text()
 text=re.sub(r'public_key = "[0-9a-f]{64}"',f'public_key = "{keys[peer]}"',text)
 p.write_text(text)
 if s==side:
  for name,content in [('demo.toml',text),('benchmark.toml',text.replace('lan_interface = "wlan0"','lan_interface = "vptbench0"'))]:
   dest=Path('/etc/vpntunnel')/name
   dest.write_text(content);dest.chmod(0o600)
for name in ['demo.toml','benchmark.toml']:
 subprocess.run(['/usr/local/bin/vptctl','check-config','/etc/vpntunnel/'+name,'--with-key'],check=True)
subprocess.run(['/usr/local/bin/vpt-bench','ready'],check=True)
