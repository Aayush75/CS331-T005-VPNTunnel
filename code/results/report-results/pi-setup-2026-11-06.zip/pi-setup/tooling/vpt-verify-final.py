from pathlib import Path
import subprocess,json,os,stat,hashlib,socket,datetime
side=Path('/etc/vpntunnel/side').read_text().strip()
home=Path('/home/cn');repo=home/'CS331-T005-VPNTunnel'
def cmd(*args):
 r=subprocess.run(args,capture_output=True,text=True,timeout=30)
 return dict(argv=args,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
data=dict(side=side,hostname=socket.gethostname(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kernel=os.uname().release,page_size=os.sysconf('SC_PAGE_SIZE'),logical_cpus=os.cpu_count())
checks={}
checks['native_kernel']=data['kernel'].startswith('6.18.') and data['page_size']==16384
checks['bench_network_active']=cmd('systemctl','is-active','vpt-benchmark-net')['returncode']==0
checks['bench_network_enabled']=cmd('systemctl','is-enabled','vpt-benchmark-net')['returncode']==0
checks['private_key_permissions']=stat.S_IMODE((Path('/etc/vpntunnel')/f'gw-{side}.key').stat().st_mode)==0o600
checks['old_repos_removed']=all(not (home/p).exists() for p in ['code','vpn','vpt-demo','tree.tar'])
checks['vpn_off']=not Path('/sys/module/vpt1_foundation').exists()
checks['cpu_evidence_saved']=(home/'pi-setup/validation-cpu/summary.json').exists()
checks['configuration_valid']=cmd('/usr/local/bin/vptctl','check-config','/etc/vpntunnel/benchmark.toml','--with-key')['returncode']==0
checks['demo_configuration_valid']=cmd('/usr/local/bin/vptctl','check-config','/etc/vpntunnel/demo.toml','--with-key')['returncode']==0
checks['clock_synchronized']='yes' in cmd('timedatectl','show','-p','NTPSynchronized')['stdout']
checks['no_throttling']='throttled=0x0' in cmd('vcgencmd','get_throttled')['stdout']
remote='10.77.2.0/24' if side=='a' else '10.77.1.0/24'
checks['vpn_off_route_guard']='unreachable' in cmd('ip','route','show','exact',remote)['stdout']
data['checks']=checks
data['commands']=[cmd('uname','-a'),cmd('ip','-j','address'),cmd('ip','-j','route'),cmd('nmcli','-f','NAME,TYPE,DEVICE','connection','show'),cmd('ethtool','eth0'),cmd('vcgencmd','measure_temp'),cmd('vcgencmd','get_throttled'),cmd('systemctl','status','vpt-benchmark-net','--no-pager'),cmd('modinfo','/usr/local/lib/vpt1/vpt1_foundation.ko')]
data['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('/usr/local/bin/vptctl'),Path('/usr/local/lib/vpt1/vpt1_foundation.ko'),Path('/usr/local/bin/vpt-bench'),Path('/usr/local/bin/vpt-cpu-monitor'),Path('/usr/local/lib/vpt1/benchmark-net.sh')]}
data['model']=Path('/proc/device-tree/model').read_text().rstrip('\x00')
data['status']='PASS' if all(checks.values()) else 'FAIL'
p=home/'pi-setup/final-readiness.json';p.write_text(json.dumps(data,indent=2)+'\n');os.chown(p,1000,1000)
print(json.dumps(dict(side=side,status=data['status'],checks=checks),indent=2))
raise SystemExit(0 if data['status']=='PASS' else 1)
