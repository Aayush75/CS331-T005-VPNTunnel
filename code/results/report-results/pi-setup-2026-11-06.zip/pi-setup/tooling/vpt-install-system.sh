#!/bin/bash
set -euo pipefail
side=${1:?side a or b}
case "$side" in a|b) ;; *) exit 2 ;; esac
repo=/home/cn/CS331-T005-VPNTunnel
install -d -m 700 /etc/vpntunnel
printf '%s\n' "$side" > /etc/vpntunnel/side
install -d -m 755 /usr/local/lib/vpt1
install -m 755 "$repo/code/control/target/release/vptctl" /usr/local/bin/vptctl
install -m 644 "$repo/code/kernel/vpt1_foundation.ko" /usr/local/lib/vpt1/
install -m 755 "$repo/code/infra/gateway/vpt-gateway.sh" "$repo/code/infra/gateway/benchmark-net.sh" /usr/local/lib/vpt1/
install -m 644 "$repo/code/infra/gateway/mss-clamp.nft" /usr/local/lib/vpt1/
install -m 755 "$repo/code/infra/gateway/pi-benchmark.sh" /usr/local/bin/vpt-bench
install -m 755 "$repo/code/tools/cpu_monitor.py" /usr/local/bin/vpt-cpu-monitor
install -m 644 "$repo/code/infra/gateway/vpt-benchmark-net.service" /etc/systemd/system/
/usr/local/bin/vptctl genkey --out "/etc/vpntunnel/gw-${side}.key" > /home/cn/pi-setup/public-key.txt
chmod 600 "/etc/vpntunnel/gw-${side}.key"
chmod 644 /home/cn/pi-setup/public-key.txt
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/vpt-benchmark-net.service
systemctl enable --now vpt-benchmark-net.service
chown -R cn:cn /home/cn/pi-setup
vptctl --version
ip -br addr show vptbench0
