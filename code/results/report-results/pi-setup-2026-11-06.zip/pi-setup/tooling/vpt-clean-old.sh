#!/bin/bash
set -euo pipefail
install -d -o cn -g cn /home/cn/pi-setup
exec > >(tee /home/cn/pi-setup/cleanup.log) 2>&1
printf 'Cleanup started: '; date -u --iso-8601=seconds
hostname
systemctl disable --now hostapd dnsmasq 2>/dev/null || true
python3 - <<'PY'
from pathlib import Path
import os,signal,time
victims=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  text=b' '.join(args).decode(errors='replace')
  executable=Path(args[0].decode()).name if args and args[0] else ''
  if executable=='vptctl' or '/home/cn/vpt-demo-web' in text or '/run/vpt-ap/' in text:
   pid=int(p.name);print('Stopping obsolete process',pid,executable);os.kill(pid,signal.SIGTERM);victims.append(pid)
 except (OSError,ValueError):pass
time.sleep(1)
for pid in victims:
 try:os.kill(pid,signal.SIGKILL)
 except ProcessLookupError:pass
PY
for t in vpt_gateway vpt_mss; do nft delete table inet "$t" 2>/dev/null || true; done
ip link delete vpn0 2>/dev/null || true
if [ -d /sys/module/vpt1_foundation ]; then rmmod vpt1_foundation; fi
ip addr flush dev wlan0
ip link set wlan0 down
iw dev wlan0 set type managed
nmcli device set wlan0 managed yes
systemctl start wpa_supplicant 2>/dev/null || true
ip link set wlan0 up
# Only inventoried old project directories and helper files are removed.
for path in /home/cn/code /home/cn/vpn /home/cn/vpt-demo /home/cn/vpt-demo-web /home/cn/vpt-demo-* /home/cn/tree.tar /home/cn/capture_icmp.py /home/cn/icmp-capture.jsonl /home/cn/admin-icmp-capture.jsonl /home/cn/protocol_server.py /home/cn/protocol_server.log /home/cn/protocol_server_k1.log /home/cn/runtime_probe.py /home/cn/apdown.sh /home/cn/aptest.sh /home/cn/rust.log /home/cn/suite.log; do
 if [ -e "$path" ]; then echo "Removing $path"; rm -rf -- "$path"; fi
done
rm -rf /run/vpt-ap /run/vpt-gateway /etc/vpntunnel /usr/local/lib/vpt1
rm -f /usr/local/bin/vptctl
nmcli connection modify vpt-demo-underlay connection.id vpt-underlay connection.autoconnect yes ipv4.never-default yes
systemctl unmask hostapd 2>/dev/null || true
printf 'Cleanup completed: '; date -u --iso-8601=seconds
ip -br addr
chown -R cn:cn /home/cn/pi-setup
