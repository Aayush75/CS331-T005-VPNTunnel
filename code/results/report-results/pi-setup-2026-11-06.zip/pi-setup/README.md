# Pi setup completed — 6 November 2026

Both Pis have been cleaned, built natively, configured and reboot-verified. These
are provisioning/readiness records, **not final hardware benchmark results**.

| | Pi A | Pi B |
|---|---|---|
| Hostname | vpn-a | vpn-b |
| Username | cn | cn |
| Persistent Ethernet address | 172.31.250.11 | 172.31.250.12 |
| Current Wi-Fi management address (DHCP) | 10.7.45.18 | 10.7.16.136 |
| Reserved dummy gateway address | 10.77.1.1 | 10.77.2.1 |
| **VPN test endpoint** | **10.77.1.10** | **10.77.2.10** |
| Temporary laptop-facing link | 100 Mbit/s | 1000 Mbit/s |
| Post-reboot readiness | PASS | PASS |

Repository on both devices: `/home/cn/CS331-T005-VPNTunnel`.
Operating instructions: [Pi Ethernet benchmark guide](tooling/pi-benchmark.md).

## Completed

- Removed inventoried old `code`, `vpn`, `vpt-demo` project directories, old capture
  helpers/logs/servers, AP processes, previous keys/configs and the old loaded module.
  Unrelated user files and generic toolchains were preserved.
- Installed the final source plus current fixes and executable shell entry points.
- Built kernel module and release controller natively on both Pis using their
  matching GCC 14 headers and Rust 1.93.1; selected the same Rust toolchain on both.
- Prepared a local vendored dependency cache for offline rebuilds. Rebuild verified
  again after reboot. Initial build setup failures are retained in the logs.
- Generated fresh, separate private identities, exchanged public keys, and validated
  benchmark and future Wi-Fi demo configs. Private keys remain root-owned/0600 under
  `/etc/vpntunnel`; no private keys or passwords are in this evidence.
- Installed `sudo vpt-bench up|down|status|ready|net-up|net-down` and
  `vpt-cpu-monitor`. The benchmark-address service is enabled at boot; the VPN itself
  remains off. An unreachable far-LAN route prevents fallback onto campus Wi-Fi.
- Verified handshake and small TCP transfers (1 MiB each direction), plus a 1-second
  low-rate UDP check. CPU recording ran on both Pis during setup verification.
- Stopped the VPN, verified the off-route guard, unloaded the module with zero
  tracked objects, rebooted both devices, and passed every final-readiness check.
- Preserved wired management and restored campus Wi-Fi station connections. Both
  current Wi-Fi SSH ports were reachable from the laptop.

## Corrections and physical limits

Initial checks incorrectly used the configured `.1` gateway addresses. The VPN
intentionally reserves these addresses from ordinary data policy. The final setup
uses separate `.10` LAN-host aliases; failed initial checks are retained alongside
successful `verified-client-*.json` checks. No kernel policy was weakened.

The current laptop bridge includes a Fast Ethernet-only RTL8152 USB adapter, so
Pi A's temporary link is limited to 100 Mbit/s. Ping loss was also observed on the
plain, unencrypted underlay (5% in a 20-probe check and 20% in a 10-probe check),
and VPN ping checks had losses too. These logs do not isolate a VPN loss rate.
Use the final direct Pi-to-Pi cable, verify negotiated speed/loss again, and run
formal measurements in fresh directories. No claim of loss-free final hardware
operation or maximum Pi VPN performance is made from these setup checks.

## Current state

Both Pis are powered on, reachable, and idle after reboot. `vptbench0` addresses
are active, private keys/configs are ready, the VPN is off, and no old AP, HTTP,
iperf or controller process is running. Clocks are synchronized; both report
`throttled=0x0`. Start the responder with `sudo vpt-bench up` on B before A.

Each Pi's `pi-setup/` directory is reproduced here, including raw CPU samples,
logs, transfer JSON, link/thermal metadata and the post-reboot checks. Historical
PIDs in text files are records only, not evidence of processes still running.
